#import <UIKit/UIKit.h>

//! Project version number for LivingMapLiveSDK.
FOUNDATION_EXPORT double LivingMapLiveSDKVersionNumber;

//! Project version string for LivingMapLiveSDK.
FOUNDATION_EXPORT const unsigned char LivingMapLiveSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LivingMapLiveSDK/PublicHeader.h>


